//
//  BlackJack.cpp
//  Oving4
//
//  Created by fredrik on 12/02/15.
//  Copyright (c) 2015 fredrik. All rights reserved.
//

#include <iostream>
#include "BlackJack.h"
#include "CardDeck.h"
#include "card.h"
#include "enumeration.h"
using namespace std;
int BlackJack::getCardValue(Card *card){
    
    int rInt;
    switch (card->getRank()) {
        case TWO:
            rInt = 2;
            break;
        case THREE:
            rInt = 3;
            break;
        case FOUR:
            rInt = 4;
            break;
        case FIVE:
            rInt = 5;
            break;
        case SIX:
            rInt = 6;
            break;
        case SEVEN:
            rInt = 7;
            break;
        case EIGHT:
            rInt = 8;
            break;
        case NINE:
            rInt = 9;
            break;
        case TEN:
            rInt = 10;
            break;
        case JACK:
            rInt = 11;
            break;
        case QUEEN:
            rInt = 12;
            break;
        case KING:
            rInt = 13;
            break;
        case ACE:
            rInt = -1;
            break;
        default:
            break;
    }
    return rInt;
    
}

bool BlackJack::isAce(Card *card){
    int theCardValue = getCardValue(card);
    
    if(theCardValue == -1){
        return true;
    }
    else{
        return false;
    }
}

int BlackJack::getPlayerCardValue(Card *card){

    int theCardValue = getCardValue(card);
    int aceValue;
    if ( isAce(card) ) {
        cout << "Du trakk en ACE, 1 / 11" << endl;
        cin >> aceValue;
        return aceValue;
    }
    else{
        return theCardValue;
    }
}

int BlackJack::getDealerCardValue(Card *card, int dealValue){

    int cardValue = getCardValue(card);
    int sumValue;
    int ace_low = 1;
    int ace_high = 11;
    
    if (isAce(card)){
        sumValue = dealValue + ace_high;
        if (sumValue > 21){
            sumValue = dealValue + ace_low;
        }
        else if(sumValue < 21){
            sumValue = dealValue + ace_high;
        }
    }
    
    else{
        sumValue = dealValue + cardValue;
        }

    return sumValue;
    
}

bool BlackJack::askPlayerDrawCard(){
    bool dealValue;
    cout << "Vil du ha et kort til (0=false, 1= true)" << endl;
    return  dealValue;

}

void BlackJack::playGame(){

    CardDeck A;
    A.shuffle();
    A.printShort();
    
    Card pc1 = A.drawCard();
    Card pc2 = A.drawCard();
    Card pc3 = A.drawCard();
    Card pc4 = A.drawCard();
    
    cout << "pc1" << endl;
    cout << pc1.getRank() << endl;
    cout << pc1.toString() << endl;
    cout << "pc2" << endl;
    cout << pc2.getRank() << endl;
    cout << pc2.toString() << endl;
    cout << pc3.getRank() << endl;
    cout << pc3.toString() << endl;
    cout << pc4.getRank() << endl;
    cout << pc4.toString() << endl;
    
}













