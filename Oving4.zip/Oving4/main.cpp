//
//  main.cpp
//  Oving4
//
//  Created by Fredrik on 09/02/15.
//  Copyright (c) 2015 fredrik. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <string>
#include "enumeration.h"
#include "card.h"
#include "CardDeck.h"
#include "BlackJack.h"


using namespace std;


int main(){
    
    bool i = true;
    
    while (i == true) {
        BlackJack::playGame();
        cin >> i;
    }

    
    
    
}